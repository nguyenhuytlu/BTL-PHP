@extends('master')

@section('content')

<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col col-md-6"><b>Music Details</b></div>
            <div class="col col-md-6">
                <a href="{{ route('musics.index') }}" class="btn btn-primary btn-sm float-end">View All</a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row mb-3">
            <label class="col-sm-2 col-label-form"><b>Track</b></label>
            <div class="col-sm-10">
                {{ $music->track }}
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-sm-2 col-label-form"><b>Artist</b></label>
            <div class="col-sm-10">
                {{ $music->artist }}
            </div>
        </div>
        <div class="row mb-4">
            <label class="col-sm-2 col-label-form"><b>Album</b></label>
            <div class="col-sm-10">
                {{ $music->album}}
            </div>
        </div>
        <div class="row mb-4">
            <label class="col-sm-2 col-label-form"><b>Played</b></label>
            <div class="col-sm-10">
                {{ $music->played}}
            </div>
        </div>
    </div>
</div>

@endsection('content')


