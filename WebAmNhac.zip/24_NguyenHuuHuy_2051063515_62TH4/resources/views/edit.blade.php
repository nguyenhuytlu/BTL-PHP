@extends('master')

@section('content')

<div class="card">
    <div class="card-header">Edit Music</div>
    <div class="card-body">
        <form method="post" action="{{ route('musics.update', $music->id) }}" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            <div class="row mb-3">
                <label class="col-sm-2 col-label-form">Track</label>
                <div class="col-sm-10">
                    <input type="text" name="track" class="form-control" value="{{ $music->track }}" />
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-2 col-label-form">Played</label>
                <div class="col-sm-10">
                    <input type="text" name="played" class="form-control" value="{{ $music->played }}" />
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-2 col-label-form">Artist</label>
                <div class="col-sm-10">
                    <input type="text" name="artist" class="form-control" value="{{ $music->artist }}" />
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-2 col-label-form">Album</label>
                <div class="col-sm-10">
                    <input type="text" name="album" class="form-control" value="{{ $music->album }}" />
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-2 col-label-form">Played</label>
                <div class="col-sm-10">
                    <input type="text" name="played" class="form-control" value="{{ $music->played }}" />
                </div>
            </div>
         
            <div class="text-center">
                <input type="hidden" name="hidden_id" value="{{ $music->id }}" />
                <input type="submit" class="btn btn-primary" value="Edit" />
            </div>
        </form>
    </div>
</div>
<script>
document.getElementsByName('artist')[0].value = "{{ $music->artist }}";
</script>

@endsection('content')
