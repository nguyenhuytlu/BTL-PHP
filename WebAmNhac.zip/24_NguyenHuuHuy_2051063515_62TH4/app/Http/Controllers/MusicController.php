<?php

namespace App\Http\Controllers;

use App\Models\Music;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class MusicController extends Controller
{
    
    public function index()
    {
        $data = Music::paginate(10);

        return view('index', compact('data'))->with('i', (request()->input('page', 1) - 1) * 5);
    }

    public function create()
    {
        return view('create');
    }
   
   
    public function store(Request $request)
    {
        $request->validate([
            'track'          =>  'required',
            'artist'         =>  'required',
            'album'          =>  'required',
            'played'         =>  'required',
        ]);

       

        $music = new Music;

        $music->track = $request->track;
        $music->artist = $request->artist;
        $music->album = $request->album;
        $music->played = $request->played;

        $music->save();

        return redirect()->route('musics.index')->with('success', 'Music Added successfully.');
    }
    public function show(Music $music)
    {
        return view('show', compact('music'));
    }

    public function edit(Music $music)
    {
        return view('edit', compact('music'));
    }

   
    public function update(Request $request, Music $music)
    {
        $request->validate([
            'track'          =>  'required',
            'artist'         =>  'required',
            'album'          =>  'required',
            'played'         =>  'required',
            
        ]);

       

        $music = Music::find($request->hidden_id);

      
        $music->track = $request->track;
        $music->artist = $request->artist;
        $music->album = $request->album;
        $music->played = $request->played;



        $music->save();

        return redirect()->route('musics.index')->with('success', 'Music Data has been updated successfully');
    }

   
    public function destroy(Music $music)
    {
        $music->delete();

        return redirect()->route('musics.index')->with('success', 'Music Data deleted successfully');
    }
    public function logout(Request $request) {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }
    public function search(Request $request){
        $query = Music::orderBy('id','DESC');
        if(isset($request->track)){
            $query = $query->where('track','like','%'.$request->track.'%');
        }
        if(isset($request->artist)){
            $query = $query->where('played','like','%'.$request->played.'%');
        }
        $data = $query->paginate(10);

        return view('index', compact('data'))->with('i', (request()->input('page', 1) - 1) * 5);
    }
}
