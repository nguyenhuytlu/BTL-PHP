<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker;

class MusicSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('music')->truncate();

        $faker = Faker\Factory::create();
        for ($i = 0; $i < 100; $i++) {
            $arr = [
                'track' => $faker->name,
                'artist' => $faker->sentence(2),
                'album' => $faker->sentence(5),
                'played' => $faker->name,
            ];
            DB::table('music')->insert($arr);
        }
    }
}
