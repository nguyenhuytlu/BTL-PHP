

<?php $__env->startSection('content'); ?>

<?php if($message = Session::get('success')): ?>

<div class="alert alert-success">
    <?php echo e($message); ?>

</div>

<?php endif; ?>


<div class="card">
    <div class="card-header">

        <div class="row">
            <div class="col col-md-6"><b>Music Data</b></div>
            <div class="col col-md-6">
                <a href="<?php echo e(route('musics.create')); ?>" class="btn btn-success btn-sm float-end">Add</a>
            </div>
        </div>
        <form method="post" action="<?php echo e(route('index.search')); ?>">
            <?php echo csrf_field(); ?>
            <input type="text" name="track" placeholder="Track">
            <input type="text" name="played" placeholder="Played">
            <input type="submit" class="btn btn-danger btn-sm" value="search" />

        </form>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <tr>
                <th>ID </th>
                <th>Track</th>
                <th>Played</th>
                <th>Artist</th>
                <th>Album</th>
                <th>Action</th>
            </tr>
            <?php if(count($data) > 0): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><?php echo e($row->id); ?></td>

                <td><?php echo e($row->track); ?></td>
                <td><?php echo e($row->played); ?></td>
                <td><?php echo e($row->artist); ?></td>
                <td><?php echo e($row->album); ?></td>

                <td>
                    <form method="post" action="<?php echo e(route('musics.destroy', $row->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <a href="<?php echo e(route('musics.show', $row->id)); ?>" class="btn btn-primary btn-sm">View</a>
                        <a href="<?php echo e(route('musics.edit', $row->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <input type="submit" class="btn btn-danger btn-sm" value="Delete" />
                    </form>

                </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php else: ?>
            <tr>
                <td colspan="5" class="text-center">No Data Found</td>
            </tr>
            <?php endif; ?>
        </table>
        <?php echo $data->links(); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\hoctap_2023\Congngheweb\BKT\24_NguyenHuuHuy_2051063515_62TH4\resources\views/index.blade.php ENDPATH**/ ?>