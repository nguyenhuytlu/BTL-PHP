

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col col-md-6"><b>Music Details</b></div>
            <div class="col col-md-6">
                <a href="<?php echo e(route('musics.index')); ?>" class="btn btn-primary btn-sm float-end">View All</a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row mb-3">
            <label class="col-sm-2 col-label-form"><b>Track</b></label>
            <div class="col-sm-10">
                <?php echo e($music->track); ?>

            </div>
        </div>
        <div class="row mb-3">
            <label class="col-sm-2 col-label-form"><b>Artist</b></label>
            <div class="col-sm-10">
                <?php echo e($music->artist); ?>

            </div>
        </div>
        <div class="row mb-4">
            <label class="col-sm-2 col-label-form"><b>Album</b></label>
            <div class="col-sm-10">
                <?php echo e($music->album); ?>

            </div>
        </div>
        <div class="row mb-4">
            <label class="col-sm-2 col-label-form"><b>Played</b></label>
            <div class="col-sm-10">
                <?php echo e($music->played); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\hoctap_2023\Congngheweb\BKT\24_NguyenHuuHuy_2051063515_62TH4\resources\views/show.blade.php ENDPATH**/ ?>